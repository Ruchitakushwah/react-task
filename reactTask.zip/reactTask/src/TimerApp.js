import React, { useState } from "react";

export default function TodoApp() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const addTask = (e) => {
    e.preventDefault();
    setTasks([...tasks, { status: false, task: newTask }]);
    setNewTask("");
  };
  const removeTask = (index) => {
    let dummyTasks = [...tasks];
    dummyTasks.splice(index, 1);
    setTasks(dummyTasks);
  };
  const toggleTask = (index) => {
    let dummyTasks = [...tasks];
    dummyTasks[index].status = !dummyTasks[index].status;
    setTasks(dummyTasks);
  };
  return (
    <div>
      {tasks.map((task, index) => {
        return (
          <div>
            <input
              type="checkbox"
              checked={task.status}
              onChange={() => {
                toggleTask(index);
              }}
            />
            <span>{task.task}</span>
            <button
              onClick={() => {
                removeTask(index);
              }}
            >
              Remove
            </button>
          </div>
        );
      })}
      {tasks.length == 0 && <div>No task Available</div>}
      <form onSubmit={addTask}>
        <input
          type="text"
          value={newTask}
          onChange={(e) => {
            setNewTask(e.target.value);
          }}
        />
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
}
