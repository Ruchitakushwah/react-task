import React, { useState } from "react";

const DragDropApp = () => {
  const [items, setItems] = useState(["Item 1", "Item 2", "Item 3", "Item 4"]);

  const handleDragStart = (e, index) => {
    e.dataTransfer.setData("index", index);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, newIndex) => {
    e.preventDefault();
    const oldIndex = e.dataTransfer.getData("index");
    const updatedItems = [...items];
    const [draggedItem] = updatedItems.splice(oldIndex, 1);
    updatedItems.splice(newIndex, 0, draggedItem);
    setItems(updatedItems);
  };

  return (
    <div>
      <h1>Drag and Drop Example</h1>
      <ul style={{ listStyle: "none" }}>
        {items.map((item, index) => (
          <li
            style={{ cursor: "move", border: "1px solid red", margin: "5px" }}
            key={index}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, index)}
          >
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DragDropApp;
