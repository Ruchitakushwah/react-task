import React, { useState } from "react";
const images = ["image1.jpg", "image2.jpg", "image3.jpg"];

function ImgGallery() {
  const [selectedImg, setSelectedImg] = useState(null);

  return (
    <div className="image-gallery">
      {images.map((image, index) => (
        <img
          key={index}
          src={image}
          alt={`Image ${index}`}
          onClick={() => setSelectedImg(image)}
        />
      ))}

      {selectedImg && (
        <div className="image-modal" onClick={() => setSelectedImg(null)}>
          <img src={selectedImg} alt="Selected Images" />
        </div>
      )}
    </div>
  );
}

export default ImgGallery;
