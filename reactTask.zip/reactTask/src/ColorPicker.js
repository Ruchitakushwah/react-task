import React, { useState } from "react";

const ColorPicker = () => {
  const [selectedColor, setSelectedColor] = useState("#d22d2d");
  const handleColorChange = (event) => {
    setSelectedColor(event.target.value);
  };

  return (
    <div>
      <h1>Color Picker</h1>
      <input type="color" value={selectedColor} onChange={handleColorChange} />

      <p>Selected Color: {selectedColor}</p>
    </div>
  );
};

export default ColorPicker;
