import React, { useState } from "react";

const Counter = () => {
  const [count, setCount] = useState(0);
  const increment = () => {
    setCount(function (preCount) {
      return (preCount += 1);
    });
  };

  const decrement = () => {
    setCount(function (preCount) {
      if (preCount > 0) {
        return (preCount -= 1);
      } else {
        return (preCount = 0);
      }
    });
  };

  return (
    <div className="App">
      <button onClick={increment}>Increment</button>
      <p>{count}</p>
      <button onClick={decrement}>Decrement</button>
    </div>
  );
};
export default Counter;
