import React, { useState } from "react";

const SearchFilter = () => {
  const [searchItem, setSearchItem] = useState("");
  const items = [
    "hello kuku",
    "any name",
    "Another item",
    "Something else",
    "More items"
  ];

  const filteredItems = items.filter((item) =>
    item.toLowerCase().includes(searchItem.toLowerCase())
  );

  return (
    <div>
      <h1>Item Filter</h1>
      <input
        type="text"
        placeholder="Search items..."
        value={searchItem}
        onChange={(e) => setSearchItem(e.target.value)}
      />
      <ul>
        {filteredItems.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default SearchFilter;
