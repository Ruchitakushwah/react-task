import React, { useState } from "react";

const Form = () => {
  const [isLogin, setIsLogin] = useState(true);
  const handleLogin = () => {
    setIsLogin(!isLogin);
  };
  if (isLogin) {
    return (
      <>
        <h1>Welcome</h1>
        <button onClick={handleLogin}>Logout</button>
      </>
    );
  } else {
    return (
      <>
        <h1>Login</h1>
        <button onClick={handleLogin}>Enter</button>
      </>
    );
  }
};
export default Form;
