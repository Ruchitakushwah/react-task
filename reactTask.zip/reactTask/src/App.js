import Counter from "./Counter";
import TogglebBtnContent from "./ToggleBtnContent";
import TimerApp from "./TimerApp";
import Form from "./Form";
import TodoApp from "./TodoApp";
import FetchingData from "./FetchinngData";
import React from "react";
import SearchFilter from "./SearchFilter";
import ImgGallery from "./ImgGallery";
import FormComponent from "./FormComponent";
import Accordion from "./Accordion";
import RouterApp from "./RouterApp";
import Forms from "./Forms";
import DragDropApp from "./DragDropApp";
import ColorPicker from "./ColorPicker";

export default function App() {
  return (
    <div className="App">
      <Counter />
      <TogglebBtnContent />
      <TimerApp />
      <Form />
      <TodoApp />
      <FetchingData />
      <SearchFilter />
      <ImgGallery />
      <FormComponent />
      <Accordion />
      <RouterApp />
      <Forms />
      <DragDropApp />
      <ColorPicker />
    </div>
  );
}
