import React, { useState } from 'react';

const TogglebBtnContent = () => {
  const [show, setShow] = useState(false);

  const toggleVisibility = () => {
    setShow(!show);
  };

  return (
    <div>
      <button onClick={toggleVisibility}>
        {show ? 'Hide Content' : 'Show Content'}
      </button>
      {show && <div>This is the hidden content.</div>}
    </div>
  );
}

export default TogglebBtnContent;