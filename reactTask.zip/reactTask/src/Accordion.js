import React, { useState } from 'react';

const Accordion =()=> {
  const sections = [
    {
      title: 'Section 1',
      content: ' Some content for Section 1',
    },
    {
      title: 'Section 2',
      content: 'Some content for Section 2',
    },
  ];

  const [openSec, setOpenSec] = useState(null);

  return (
    <div>
      <h1>Accordion</h1>
      <ul>
        {sections.map((section, index) => (
          <li key={index}>
            <button onClick={() => setOpenSec(openSec === index ? null : index)}>
              {section.title}
            </button>
            {openSec === index && <div>{section.content}</div>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Accordion;