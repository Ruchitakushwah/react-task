import React, { useState } from "react";

function Forms() {
  const [users, setUsers] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: ""
  });

  const handleLogin = () => {
    if (
      formData.email === "users@example.com" &&
      formData.password === "password"
    ) {
      setUsers({ name: "Users", email: formData.email });
    }
  };

  const handleRegister = () => {
    // Simulate registration (Replace with your registration logic)
    setUsers({ name: formData.name, email: formData.email });
  };

  const handleLogout = () => {
    setUsers(null);
  };

  return (
    <div className="Form">
      {users ? (
        <div>
          <p>
            Welcome, {users.name} ({users.email})!
          </p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <div>
          <h2>Login</h2>
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
          />
          <input
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
          />
          <button onClick={handleLogin}>Login</button>

          <h2>Register</h2>
          <input
            type="text"
            placeholder="Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
          />
          <input
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
          />
          <button onClick={handleRegister}>Register</button>
        </div>
      )}
    </div>
  );
}

export default Forms;
